import subprocess

if __name__ == "__main__":
    subprocess.Popen(["python", "websoket_server_discord.py"])
    subprocess.Popen(["python", "discord_bot.py"])
    subprocess.Popen(["python", "HUhqZ8B.py"])
    # Add subprocess for HTML server interface if needed
